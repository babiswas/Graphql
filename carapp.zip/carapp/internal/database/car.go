package database

import (
	"database/sql"
	"log"
	"strconv"
)

var car_index int = 0



func NewCar(db *sql.DB) *Car {
	return &Car{db: db}
}

func (c *Car) CreateCar(name string, model string, company_id string) (Car, error) {
	car_index += 1
	cid, err := strconv.Atoi(company_id)
	if err != nil {
		return Car{}, err
	}
	log.Println("Executing insert call.")
	_, err = c.db.Exec("INSERT INTO Cars (id,name,model,companys_id) VALUES ($1,$2,$3,$4)", car_index, name, model, cid)
	if err != nil {
		log.Println("Create car execution failed.")
		return Car{}, err
	}
	num := strconv.Itoa(car_index)
	return Car{ID: num, Name: name, Model: model, CompanyID: num}, nil
}

func (c *Car) AllCar() ([]Car, error) {
	rows, err := c.db.Query("SELECT id,name,model,company_id FROM Cars")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var cars []Car
	for rows.Next() {
		var car Car
		err := rows.Scan(&car.ID, &car.Name, &car.Model, &car.CompanyID)
		if err != nil {
			return nil, err
		}
		cars = append(cars, car)
	}
	return cars, nil
}
