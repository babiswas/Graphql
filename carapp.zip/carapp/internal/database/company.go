package database

import (
	"database/sql"
	"strconv"
)

var index int = 4



func NewCompany(db *sql.DB) *Company {
	return &Company{db: db}
}

func (c *Company) Create(name string) (Company, error) {
	index += 1
	_, err := c.db.Exec("INSERT INTO Companys (id,name) VALUES ($1,$2)", index, name)
	if err != nil {
		return Company{}, err
	}
	num := strconv.Itoa(index)
	return Company{ID: num, Name: name}, nil
}

func (c *Company) GetCompanyByID(company_id string) (Company, error) {
	index, err := strconv.Atoi(company_id)
	if err != nil {
		return Company{}, err
	}
	row := c.db.QueryRow("SELECT id,name FROM Companys WHERE id=($1)", index)
	var company Company
	err = row.Scan(&company.ID, &company.Name)
	if err != nil {
		return Company{}, err
	}
	return company, nil
}

func (c *Company) FindAll() ([]Company, error) {
	rows, err := c.db.Query("SELECT id, name FROM Companys")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var companys []Company
	for rows.Next() {
		var company Company
		err := rows.Scan(&company.ID, &company.Name)
		if err != nil {
			return nil, err
		}
		companys = append(companys, company)
	}
	return companys, nil
}
