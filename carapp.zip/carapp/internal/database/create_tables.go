package database

import (
	"database/sql"
	"log"
)

func CreateTableCompany(db *sql.DB) {
	log.Println("Creating table company.")
	query := `CREATE TABLE IF NOT EXISTS companys (
	   id SERIAL PRIMARY KEY,
	   name VARCHAR(100) NOT NULL
	)`
	_, err := db.Exec(query)
	if err != nil {
		log.Fatal(err)
	}
}

func CreateTableCars(db *sql.DB) {
	log.Println("Creating table cars.")
	query := `CREATE TABLE IF NOT EXISTS cars (
	   id SERIAL PRIMARY KEY,
	   name VARCHAR(100) NOT NULL,
	   model VARCHAR(100) NOT NULL,
	   companys_id integer REFERENCES companys
	)`
	_, err := db.Exec(query)
	if err != nil {
		log.Fatal(err)
	}
}
