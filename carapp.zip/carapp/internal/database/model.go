package database

import (
	"gorm.io/gorm"
)

type Company struct {
	gorm.Model
	ID   string
	Name string
}

type Car struct {
	gorm.Model
	ID        string
	Name      string
	Model     string
	CompanyID int
    Company   Company
}
