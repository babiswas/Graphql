package crud

import (
	"showroom/internal/database"
	"strconv"

	"gorm.io/gorm"
)

type CarService struct {
	DB *gorm.DB
}

func NewCarService(db *gorm.DB) *CarService {
	return &CarService{
		DB: db,
	}
}

func (s *CarService) CreateCar(name string, carmodel string, company_id string) (*database.Car, error) {
	company_index, err := strconv.Atoi(company_id)
	if err != nil {
		return nil, err
	}
	car := &database.Car{
		Name:      name,
		Carmodel:  carmodel,
		CompanyID: company_index,
	}
	err = s.DB.Create(&car).Error
	return car, err
}

func (s *CarService) ShowCars() ([]*database.Car, error) {
	cars := []*database.Car{}
	err := s.DB.Find(&cars).Error
	return cars, err
}

var _ CarRepo = &CarService{}
