package crud

import (
	"showroom/internal/database"

	"gorm.io/gorm"
)

type ShowroomService struct {
	DB *gorm.DB
}

func NewShowRoomService(db *gorm.DB) *ShowroomService {
	return &ShowroomService{
		DB: db,
	}
}

func (s *ShowroomService) CreateCompany(name string) (*database.Company, error) {
	company := &database.Company{
		Name: name,
	}
	result := s.DB.Create(&company)
	return company, result.Error
}

func (s *ShowroomService) ShowCompanies() ([]*database.Company, error) {
	companies := []*database.Company{}
	err := s.DB.Find(&companies).Error
	return companies, err
}

func (s *ShowroomService) GetCompany(company_id string) (*database.Company, error) {
	company := database.Company{}
	err := s.DB.First(&company, company_id).Error
	return &company, err
}

var _ ShowroomRepo = &ShowroomService{}
