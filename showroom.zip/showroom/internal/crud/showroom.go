package crud

import "showroom/internal/database"

type ShowroomRepo interface {
	CreateCompany(name string) (*database.Company, error)
	ShowCompanies() ([]*database.Company, error)
	GetCompany(company_id string) (*database.Company, error)
}

type CarRepo interface {
	CreateCar(name string, carmodel string, company_id string) (*database.Car, error)
	ShowCars() ([]*database.Car, error)
}
