package database

import (
	"gorm.io/gorm"
)

type Company struct {
	gorm.Model
	Name string
}

type Car struct {
	gorm.Model
	Name      string
	Carmodel  string
	CompanyID int
	Company   Company
}
