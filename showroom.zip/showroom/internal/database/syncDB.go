package database

func SyncDatabase() {
	DB.AutoMigrate(&Company{})
	DB.AutoMigrate(&Car{})
}
